<!-- Footer -->
    <footer>
      <div class="container text-center">
        <p>Copyright &copy; Pangestu 2017</p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Include SmartCart -->
    <script src="js/jquery.smartCart.min.js" type="text/javascript"></script>
    
    <!-- Custom scripts for this template -->
    <script src="js/style.min.js"></script>

  </body>

</html>
